import bpy, bmesh, math, os
from mathutils import Vector, Matrix, noise

def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.scene.unit_settings.system = 'METRIC'

def build_stone():
    # Start from an icosphere, flatten top, add organic noise displacement
    me = bpy.data.meshes.new("SM_TextStone")
    ob = bpy.data.objects.new("SM_TextStone", me)
    bpy.context.scene.collection.objects.link(ob)
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=4, radius=1.0)
    # river-stone proportions: wide, medium deep, flatter
    for v in bm.verts:
        v.co.x *= 1.30
        v.co.y *= 0.95
        v.co.z *= 0.62
    # flatten the top into a gentle writing plateau
    for v in bm.verts:
        if v.co.z > 0.18:
            t = (v.co.z - 0.18) / (0.62*1.0)   # 0..~
            v.co.z = 0.18 + (v.co.z - 0.18) * 0.35   # compress upper dome
    # organic lumpiness via noise, but keep the top calm for legibility
    for v in bm.verts:
        n = noise.noise(v.co * 1.7)
        calm = max(0.0, min(1.0, (v.co.z - 0.10) / 0.25))  # 1 near top
        amp = 0.10 * (1.0 - 0.7*calm)
        v.co += v.normal * n * amp
        # small secondary detail
        v.co += v.normal * noise.noise(v.co * 4.3) * 0.025 * (1.0-0.5*calm)
    # settle base flat so it rests on ground
    minz = min(v.co.z for v in bm.verts)
    for v in bm.verts:
        v.co.z -= minz
        if v.co.z < 0.02:
            v.co.z = 0.0   # flat contact base
    bm.normal_update()

    # --- UVs: smart project would need operator; do a simple planar-top +
    # spherical body so the photographed stone reads on top and sides ---
    uvl = bm.loops.layers.uv.new("UVMap")
    # bounds
    xs=[v.co.x for v in bm.verts]; ys=[v.co.y for v in bm.verts]; zs=[v.co.z for v in bm.verts]
    minx,maxx=min(xs),max(xs); miny,maxy=min(ys),max(ys); maxz=max(zs)
    cx,cy=(minx+maxx)/2,(miny+maxy)/2
    for f in bm.faces:
        # decide top vs side by face normal
        if f.normal.z > 0.55:   # top-facing -> planar projection (for text)
            for l in f.loops:
                co=l.vert.co
                l[uvl].uv=((co.x-minx)/(maxx-minx), (co.y-miny)/(maxy-miny))
        else:                   # sides -> cylindrical
            for l in f.loops:
                co=l.vert.co
                ang=math.atan2(co.y-cy, co.x-cx)/(2*math.pi)+0.5
                l[uvl].uv=(ang, co.z/maxz)
    bm.to_mesh(me); bm.free()
    me.polygons.foreach_set("use_smooth",[True]*len(me.polygons))

    # origin to base-center
    bpy.context.view_layer.objects.active = ob
    bpy.context.scene.cursor.location = (cx, cy, 0)
    ob.select_set(True)
    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
    ob.location=(0,0,0)
    # scale to a friendly ~0.5m wide stone
    ob.scale=(0.19,0.19,0.19); bpy.ops.object.transform_apply(scale=True)

    # add a socket empty just above the top plateau for text placement
    e=bpy.data.objects.new("SOCKET_Text",None)
    e.empty_display_type='PLAIN_AXES'; e.empty_display_size=0.05
    bpy.context.scene.collection.objects.link(e)
    e.parent=ob
    topz=max(v.co.z for v in me.vertices)*ob.scale.z
    e.location=(0,0,topz+0.005)
    e.rotation_euler=(math.radians(-90),0,0)  # face up for a text mesh
    return ob

def make_material(ob):
    m=bpy.data.materials.new("M_TextStone"); m.use_nodes=True
    nt=m.node_tree; bsdf=nt.nodes["Principled BSDF"]
    tex=nt.nodes.new("ShaderNodeTexImage")
    img=bpy.data.images.load(os.path.abspath("tex/T_Stone_Albedo.png"))
    tex.image=img; nt.links.new(tex.outputs["Color"],bsdf.inputs["Base Color"])
    r=nt.nodes.new("ShaderNodeTexImage")
    rimg=bpy.data.images.load(os.path.abspath("tex/T_Stone_Rough.png"))
    rimg.colorspace_settings.name='Non-Color'; r.image=rimg
    nt.links.new(r.outputs["Color"],bsdf.inputs["Roughness"])
    bsdf.inputs["Roughness"].default_value=0.85
    ob.data.materials.append(m)

def export(ob):
    os.makedirs("out",exist_ok=True)
    for o in bpy.context.selected_objects: o.select_set(False)
    ob.select_set(True)
    for c in ob.children_recursive: c.select_set(True)
    bpy.context.view_layer.objects.active=ob
    tri=ob.modifiers.new("Tri",'TRIANGULATE')
    bpy.ops.export_scene.fbx(filepath=os.path.abspath("out/SM_TextStone.fbx"),
        use_selection=True, axis_forward='-Z', axis_up='Y',
        apply_scale_options='FBX_SCALE_UNITS', use_mesh_modifiers=True,
        mesh_smooth_type='OFF', use_tspace=True, add_leaf_bones=False,
        bake_space_transform=True, object_types={'MESH','EMPTY'})
    ob.modifiers.remove(tri)

reset()
stone=build_stone()
make_material(stone)
tris=sum(len(p.vertices)-2 for p in stone.data.polygons)
export(stone)
bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath("out/stone_source.blend"))
print("TRIS", tris, "dims", tuple(round(d,3) for d in stone.dimensions))
