"""
=============================================================================
 THE GREAT LIBRARY — Island & Library Exterior Generator (bpy)
=============================================================================
 The arrival moment: a stylized island on a teal sea, a winding path from a
 little dock up to the Great Library — glowing windows, dome, towers — where
 the reading adventure begins.

 Exports (Models_Island/ — keep OUTSIDE the trim pipeline so the painted
 base-colour materials import as-is, like the characters):
   SM_Island_Terrain     heightfield island: grass / cliff / beach materials
   SM_Island_Sea         sea disc
   SM_Library_Exterior   the hero building (steps, portico, dome, towers,
                         glowing windows, arched entrance) + SOCKET_Entrance
   SM_Tree_A / SM_Tree_B round + tall stylized trees
   SM_Dock, SM_Boat      the student's arrival point
   SM_Crystal_Float      floating knowledge crystal (emissive violet)
   SM_LanternPost        path lantern
   SM_Island_Vista       the ENTIRE composed island as one multi-root FBX —
                         drag once into Unity and the vista just stands there.
 Render-only objects are prefixed RENDER_ and never exported.
=============================================================================
"""
import os, sys, json, math, random
os.environ.setdefault("KIT_OUT", "/home/claude/island/out")
os.environ.setdefault("KIT_TEX", "/home/claude/kitgen/tex")
sys.path.insert(0, "/home/claude/kitgen")

import bpy, bmesh
from mathutils import Vector, Matrix, Euler
from kit_generator import (reset_scene, link, tri_count, _arch_cut)

OUT = "/home/claude/island/out/Models_Island"
SEED = 20260723
rng = random.Random(SEED)

# ------------------------------------------------------------ materials ----
def cmat(name, rgb, rough=0.85, emit=None, strength=0.0):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    nd = m.node_tree.nodes["Principled BSDF"]
    nd.inputs["Base Color"].default_value = (*rgb, 1)
    nd.inputs["Roughness"].default_value = rough
    if emit:
        nd.inputs["Emission Color"].default_value = (*emit, 1)
        nd.inputs["Emission Strength"].default_value = strength
    return m

def MATS():
    return dict(
        grass  = cmat("M_Grass",      (0.32, 0.55, 0.24)),
        cliff  = cmat("M_Cliff",      (0.45, 0.40, 0.36)),
        beach  = cmat("M_Beach",      (0.87, 0.78, 0.55)),
        sea    = cmat("M_Sea",        (0.16, 0.42, 0.52), 0.25,
                      emit=(0.10, 0.30, 0.38), strength=0.25),
        stone  = cmat("M_StoneWarm",  (0.78, 0.71, 0.58)),
        stone2 = cmat("M_StoneDeep",  (0.60, 0.53, 0.44)),
        roof   = cmat("M_RoofTeal",   (0.22, 0.45, 0.44)),
        gold   = cmat("M_GoldTrim",   (0.85, 0.63, 0.25), 0.35),
        glow   = cmat("M_WindowGlow", (1.0, 0.78, 0.35), 0.6,
                      emit=(1.0, 0.72, 0.30), strength=3.0),
        wood   = cmat("M_WoodDark",   (0.33, 0.22, 0.14)),
        trunk  = cmat("M_Trunk",      (0.36, 0.25, 0.16)),
        can1   = cmat("M_Canopy_A",   (0.30, 0.52, 0.26)),
        can2   = cmat("M_Canopy_B",   (0.40, 0.60, 0.28)),
        cryst  = cmat("M_CrystalViolet", (0.42, 0.30, 0.75), 0.3,
                      emit=(0.55, 0.40, 1.0), strength=2.2),
        sail   = cmat("M_SailCream",  (0.94, 0.90, 0.80)),
        path   = cmat("M_PathSand",   (0.80, 0.70, 0.52)),
        sky    = cmat("RENDER_M_Sky", (0.62, 0.78, 0.94), 1.0,
                      emit=(0.62, 0.78, 0.94), strength=1.0),
        cloud  = cmat("RENDER_M_Cloud",(0.97, 0.97, 1.0), 1.0,
                      emit=(0.9, 0.92, 1.0), strength=0.6),
    )

# ------------------------------------------------------------ mesh utils ---
def mesh_obj(name):
    ob = bpy.data.objects.new(name, bpy.data.meshes.new(name))
    link(ob)
    return ob, bmesh.new()

def commitm(ob, bm, mats, smooth=True):
    bm.normal_update(); bm.to_mesh(ob.data); bm.free()
    for m in mats: ob.data.materials.append(m)
    if smooth:
        ob.data.polygons.foreach_set("use_smooth",
                                     [True]*len(ob.data.polygons))
    return ob

def bx(bm, size, center, midx=0):
    v = bmesh.ops.create_cube(bm, size=1.0)['verts']
    bmesh.ops.transform(bm, matrix=Matrix.Translation(Vector(center)) @
                        Matrix.Diagonal((*size, 1)).to_4x4(), verts=v)
    for f in {f for vv in v for f in vv.link_faces}: f.material_index = midx
    return v

def cyl(bm, r1, r2, depth, segs, center, midx=0, cap=True):
    res = bmesh.ops.create_cone(bm, cap_ends=cap, segments=segs,
                                radius1=r1, radius2=r2, depth=depth)
    bmesh.ops.transform(bm, matrix=Matrix.Translation(Vector(center)),
                        verts=res['verts'])
    for f in {f for vv in res['verts'] for f in vv.link_faces}:
        f.material_index = midx
    return res['verts']

def sph(bm, r, segs, rings, center, scale=(1,1,1), midx=0):
    res = bmesh.ops.create_uvsphere(bm, u_segments=segs, v_segments=rings,
                                    radius=r)
    bmesh.ops.transform(bm, matrix=Matrix.Translation(Vector(center)) @
                        Matrix.Diagonal((*scale, 1)).to_4x4(),
                        verts=res['verts'])
    for f in {f for vv in res['verts'] for f in vv.link_faces}:
        f.material_index = midx
    return res['verts']

def vnoise(x, y):
    return (math.sin(x*1.7+2.1)*math.cos(y*1.3+0.7)*0.5 +
            math.sin(x*3.9+5.0)*math.cos(y*3.1+1.9)*0.3 +
            math.sin(x*8.1)*math.cos(y*7.3)*0.2)

# ===========================================================================
#  TERRAIN + SEA
# ===========================================================================
def build_terrain(M):
    ob, bm = mesh_obj("SM_Island_Terrain")
    res = bmesh.ops.create_grid(bm, x_segments=44, y_segments=44, size=1.0)
    R_TOP, R_EDGE = 5.6, 8.6
    for v in res['verts']:
        x, y = v.co.x*9.0, v.co.y*9.0
        r = math.hypot(x, y)
        n = vnoise(x*0.5, y*0.5)
        if r < R_TOP:
            z = 1.85 + n*0.28 - (r/R_TOP)**2 * 0.35
        elif r < R_EDGE:
            t = (r - R_TOP) / (R_EDGE - R_TOP)
            z = (1.55 + n*0.22) * (1 - t)**1.6 - 1.4*t + n*0.15*(1-t)
        else:
            z = -1.5
        v.co = Vector((x, y, z))
    bm.faces.ensure_lookup_table()
    for f in bm.faces:                                  # material by height
        cz = sum(vv.co.z for vv in f.verts)/len(f.verts)
        cr = math.hypot(*[sum(vv.co.x for vv in f.verts)/len(f.verts),
                          sum(vv.co.y for vv in f.verts)/len(f.verts)])
        if cz > 1.15 and cr < R_TOP + 0.4: f.material_index = 0   # grass
        elif -0.25 < cz < 0.35:            f.material_index = 2   # beach
        else:                              f.material_index = 1   # cliff
    commitm(ob, bm, [M['grass'], M['cliff'], M['beach']])
    return ob

def build_sea(M):
    ob, bm = mesh_obj("SM_Island_Sea")
    cyl(bm, 34, 34, 0.05, 48, (0, 0, -0.03))
    commitm(ob, bm, [M['sea']])
    return ob

# ===========================================================================
#  THE GREAT LIBRARY — exterior hero
# ===========================================================================
def build_library(M):
    ob, bm = mesh_obj("SM_Library_Exterior")
    S, S2, RF, G, W = 0, 1, 2, 3, 4          # material slots
    # platform + grand steps (front faces -Y)
    bx(bm, (7.4, 5.6, 0.5), (0, 0.6, 0.25), S2)
    for i in range(5):
        bx(bm, (5.2 - i*0.0, 0.55, 0.28),
           (0, -2.5 - i*0.55, 0.25 - i*0.28 + 0.55), S)
    # main hall
    bx(bm, (5.6, 4.2, 3.0), (0, 1.0, 2.0), S)
    bx(bm, (5.8, 4.4, 0.35), (0, 1.0, 3.62), G)          # cornice
    # portico: 4 columns + entablature + pediment
    for cx in (-1.95, -0.65, 0.65, 1.95):
        cyl(bm, 0.22, 0.19, 2.4, 10, (cx, -1.65, 1.85), S)
        bx(bm, (0.55, 0.55, 0.12), (cx, -1.65, 0.62), S2)
        bx(bm, (0.50, 0.50, 0.10), (cx, -1.65, 3.06), G)
    bx(bm, (4.9, 0.7, 0.35), (0, -1.65, 3.3), S)
    ped = cyl(bm, 2.75, 2.75, 0.55, 3, (0, 0, 0), RF, cap=True)  # pediment
    bmesh.ops.transform(bm, matrix=Matrix.Translation((0, -1.62, 3.62)) @
                        Matrix.Rotation(math.radians(90), 4, 'X') @
                        Matrix.Rotation(math.radians(90), 4, 'Z') @
                        Matrix.Diagonal((1, 0.42, 1, 1)).to_4x4(), verts=ped)
    # drum + dome + finial
    cyl(bm, 1.7, 1.7, 0.8, 16, (0, 1.0, 3.9), S)
    sph(bm, 1.72, 18, 12, (0, 1.0, 4.3), (1, 1, 0.78), RF)
    cyl(bm, 0.10, 0.06, 0.7, 8, (0, 1.0, 5.95), G)
    sph(bm, 0.16, 8, 6, (0, 1.0, 6.35), midx=G)
    # side towers + conical roofs + glow windows
    for tx in (-3.3, 3.3):
        cyl(bm, 0.75, 0.68, 4.2, 12, (tx, 1.4, 2.35), S)
        cyl(bm, 0.95, 0.02, 1.5, 12, (tx, 1.4, 5.2), RF)
        sph(bm, 0.10, 8, 6, (tx, 1.4, 6.0), midx=G)
        for wz in (2.0, 3.3):
            bx(bm, (0.28, 0.1, 0.5), (tx, 0.62, wz), W)
    # facade windows (two tiers, glowing)
    for wx in (-2.2, -1.3, 1.3, 2.2):
        bx(bm, (0.42, 0.1, 0.9), (wx, -1.12, 2.2), W)
    for wx in (-1.6, 0, 1.6):
        bx(bm, (0.42, 0.1, 0.62), (wx, -1.12, 3.1), W)
    commitm(ob, bm, [M['stone'], M['stone2'], M['roof'], M['gold'], M['glow']],
            smooth=True)
    # arched entrance cut + warm door glow plane
    _arch_cut(ob, 1.5, 2.1, 1.85, depth=6.0)
    d, db = mesh_obj("SM_Library_Exterior_DoorGlow")
    bx(db, (1.44, 0.05, 1.45), (0, -1.05, 1.28))
    a = cyl(db, 0.72, 0.72, 0.05, 16, (0, 0, 0))
    bmesh.ops.transform(db, matrix=Matrix.Translation((0, -1.05, 2.0)) @
                        Matrix.Rotation(math.radians(90), 4, 'X'), verts=a)
    commitm(d, db, [M['glow']])
    d.parent = ob
    e = bpy.data.objects.new("SOCKET_Entrance", None)
    e.empty_display_type = 'PLAIN_AXES'; link(e)
    e.parent = ob; e.location = (0, -2.2, 1.0)
    return ob

# ===========================================================================
#  DRESSING: trees, dock, boat, crystals, lanterns, path
# ===========================================================================
def build_tree(M, tall):
    ob, bm = mesh_obj("SM_Tree_B" if tall else "SM_Tree_A")
    if tall:
        cyl(bm, 0.10, 0.07, 1.6, 8, (0, 0, 0.8), 0)
        sph(bm, 0.55, 10, 8, (0, 0, 1.9), (0.8, 0.8, 1.35), 1)
        sph(bm, 0.38, 10, 8, (0, 0, 2.6), (0.8, 0.8, 1.1), 2)
    else:
        cyl(bm, 0.12, 0.09, 0.9, 8, (0, 0, 0.45), 0)
        sph(bm, 0.62, 12, 8, (0, 0, 1.25), (1, 1, 0.85), 1)
        sph(bm, 0.42, 10, 8, (0.35, 0.15, 1.55), midx=2)
        sph(bm, 0.36, 10, 8, (-0.3, -0.1, 1.5), midx=1)
    commitm(ob, bm, [M['trunk'], M['can1'], M['can2']])
    return ob

def build_dock(M):
    ob, bm = mesh_obj("SM_Dock")
    for i in range(6):
        bx(bm, (1.5, 0.42, 0.06), (0, -i*0.46, 0.32), 0)
    for sx in (-0.65, 0.65):
        for py in (0, -1.15, -2.3):
            cyl(bm, 0.07, 0.06, 0.9, 8, (sx, py, -0.05), 0)
    commitm(ob, bm, [M['wood']])
    return ob

def build_boat(M):
    ob, bm = mesh_obj("SM_Boat")
    sph(bm, 0.6, 14, 10, (0, 0, 0.18), (0.55, 1.35, 0.42), 0)   # hull
    bx(bm, (0.55, 0.12, 0.05), (0, 0, 0.34), 0)                  # bench
    cyl(bm, 0.035, 0.02, 1.5, 8, (0, 0.25, 1.0), 0)              # mast
    sail = cyl(bm, 0.55, 0.55, 0.03, 3, (0, 0, 0), 1)            # tri sail
    bmesh.ops.transform(bm, matrix=Matrix.Translation((0.02, 0.25, 1.15)) @
                        Matrix.Rotation(math.radians(90), 4, 'Y') @
                        Matrix.Diagonal((1, 0.75, 1, 1)).to_4x4(), verts=sail)
    commitm(ob, bm, [M['wood'], M['sail']])
    return ob

def build_crystal(M):
    ob, bm = mesh_obj("SM_Crystal_Float")
    res = bmesh.ops.create_icosphere(bm, subdivisions=1, radius=0.28)
    bmesh.ops.transform(bm, matrix=Matrix.Diagonal((0.7, 0.7, 1.5, 1)).to_4x4(),
                        verts=res['verts'])
    commitm(ob, bm, [M['cryst']], smooth=False)
    return ob

def build_lantern_post(M):
    ob, bm = mesh_obj("SM_LanternPost")
    cyl(bm, 0.05, 0.04, 1.4, 8, (0, 0, 0.7), 0)
    sph(bm, 0.11, 8, 6, (0, 0, 1.5), midx=1)
    commitm(ob, bm, [M['wood'], M['glow']])
    return ob

def build_path(M):
    ob, bm = mesh_obj("SM_Island_Path")
    pts = [(0, -2.9), (0.35, -3.7), (0.15, -4.6), (-0.4, -5.4),
           (-0.5, -6.2), (-0.15, -6.9)]
    for i, (px, py) in enumerate(pts):
        z = 1.75 - i*0.28
        s = bx(bm, (1.15, 1.0, 0.10), (px, py, max(z, 0.34)), 0)
    commitm(ob, bm, [M['path']])
    return ob

# ===========================================================================
#  COMPOSE THE VISTA
# ===========================================================================
def compose(M):
    exports = []
    terrain = build_terrain(M); exports.append(terrain)
    sea = build_sea(M);         exports.append(sea)
    lib = build_library(M);     lib.location = (0, 1.3, 1.62)
    exports.append(lib)
    path = build_path(M);       exports.append(path)
    dock = build_dock(M);       dock.location = (-0.15, -7.3, 0.0)
    exports.append(dock)
    boat = build_boat(M);       boat.location = (0.55, -9.6, 0.02)
    boat.rotation_euler = Euler((0, 0, math.radians(15)))
    exports.append(boat)

    treeA = build_tree(M, False); treeB = build_tree(M, True)
    exports += [treeA, treeB]
    spots = []
    while len(spots) < 12:
        a, r = rng.uniform(0, 2*math.pi), rng.uniform(2.6, 5.0)
        x, y = math.cos(a)*r, math.sin(a)*r
        if -3.6 < x < 3.6 and -3.6 < y < 4.2: continue   # library clearing
        if any((x-sx)**2 + (y-sy)**2 < 1.4 for sx, sy in spots): continue
        spots.append((x, y))
    tree_copies = []
    for i, (x, y) in enumerate(spots):
        src = treeA if i % 3 else treeB
        c = src.copy(); c.data = src.data; link(c)
        c.location = (x, y, 1.55 + vnoise(x*0.5, y*0.5)*0.25)
        c.scale = (s := rng.uniform(0.8, 1.25), s, s)
        c.rotation_euler = Euler((0, 0, rng.uniform(0, 6.28)))
        c.name = "RENDER_tree_%d" % i
        tree_copies.append(c)
    treeA.location = (2.9, -1.4, 1.7)
    treeB.location = (-3.1, -0.6, 1.75)

    cry = build_crystal(M); exports.append(cry)
    cry.location = (2.4, 2.8, 4.4)
    for i, (cx, cy, cz) in enumerate([(-2.6, 3.1, 4.1), (3.4, 0.2, 3.6),
                                      (-3.6, -1.8, 3.4)]):
        c = cry.copy(); c.data = cry.data; link(c)
        c.location = (cx, cy, cz); c.name = "RENDER_crystal_%d" % i
        c.rotation_euler = Euler((0.2, 0.1, rng.uniform(0, 3)))

    post = build_lantern_post(M); exports.append(post)
    post.location = (0.75, -3.3, 1.45)
    for i, (px, py, pz) in enumerate([(-0.9, -4.9, 0.95), (0.4, -6.6, 0.5)]):
        c = post.copy(); c.data = post.data; link(c)
        c.location = (px, py, pz); c.name = "RENDER_post_%d" % i

    # render-only sky + clouds
    sky, sb = mesh_obj("RENDER_Sky")
    res = bmesh.ops.create_uvsphere(sb, u_segments=24, v_segments=16, radius=55)
    for f in sb.faces: f.normal_flip()
    commitm(sky, sb, [M['sky']])
    for i in range(4):
        cl, cb = mesh_obj("RENDER_Cloud_%d" % i)
        base = Vector((rng.uniform(-16, 16), rng.uniform(4, 18),
                       rng.uniform(6.5, 10)))
        for k in range(3):
            sph(cb, rng.uniform(1.2, 2.2), 10, 6,
                base + Vector((k*1.6 - 1.6, rng.uniform(-0.4, 0.4), 0)),
                (1, 0.8, 0.45))
        commitm(cl, cb, [M['cloud']])
    return exports

# ===========================================================================
#  EXPORT + MAIN
# ===========================================================================
def fbx_export(objs, path):
    for o in bpy.context.selected_objects: o.select_set(False)
    for o in objs:
        o.select_set(True)
        for ch in o.children_recursive: ch.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.export_scene.fbx(
        filepath=path, use_selection=True,
        axis_forward='-Z', axis_up='Y',
        apply_scale_options='FBX_SCALE_UNITS',
        use_mesh_modifiers=True, mesh_smooth_type='OFF',
        use_tspace=False, add_leaf_bones=False,
        object_types={'MESH', 'EMPTY'})

def main():
    print("=" * 70); print(" ISLAND & LIBRARY EXTERIOR"); print("=" * 70)
    os.makedirs(OUT, exist_ok=True)
    reset_scene()
    M = MATS()
    exports = compose(M)
    manifest = []
    for ob in exports:
        tris = tri_count(ob) + sum(tri_count(c) for c in ob.children_recursive
                                   if c.type == 'MESH')
        fbx_export([ob], os.path.join(OUT, ob.name + ".fbx"))
        manifest.append(dict(name=ob.name, tris=tris))
        print(f"  {ob.name:26s} {tris:6d} tris")
    # composed vista: every non-RENDER mesh in one FBX
    vista = [o for o in bpy.context.scene.objects
             if o.type == 'MESH' and not o.name.startswith("RENDER_")]
    fbx_export(vista, os.path.join(OUT, "SM_Island_Vista.fbx"))
    total = sum(m['tris'] for m in manifest)
    manifest.append(dict(name="SM_Island_Vista", tris="composed all above"))
    with open("/home/claude/island/out/island_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)
    bpy.ops.wm.save_as_mainfile(
        filepath="/home/claude/island/out/island_source.blend")
    print("-" * 70)
    print(f"  {len(manifest)} exports | ~{total:,} unique tris")

if __name__ == "__main__":
    main()
